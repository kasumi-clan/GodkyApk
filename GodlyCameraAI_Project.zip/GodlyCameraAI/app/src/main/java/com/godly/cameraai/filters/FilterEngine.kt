package com.godly.cameraai.filters

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint

enum class GodlyFilterStyle(val displayName: String) {
    ORIGINAL("Original (Gốc)"),
    LEICA_INSPIRED("Leica-Inspired"),
    ZEISS_INSPIRED("ZEISS-Inspired"),
    HASSELBLAD_INSPIRED("Hasselblad-Inspired"),
    IOS_INSPIRED("iOS-Inspired"),
    NIGHT_NATURAL("Night Natural"),
    CINEMATIC("Cinematic"),
    PORTRAIT_WARM("Portrait"),
    BLACK_AND_WHITE("Black & White")
}

class FilterEngine {

    var currentStyle: GodlyFilterStyle = GodlyFilterStyle.ORIGINAL
    var filterIntensity: Float = 1.0f

    private val identityMatrix = floatArrayOf(
        1f, 0f, 0f, 0f, 0f,
        0f, 1f, 0f, 0f, 0f,
        0f, 0f, 1f, 0f, 0f,
        0f, 0f, 0f, 1f, 0f
    )

    private fun getBaseMatrix(style: GodlyFilterStyle): FloatArray {
        return when (style) {
            GodlyFilterStyle.ORIGINAL -> identityMatrix
            GodlyFilterStyle.LEICA_INSPIRED -> floatArrayOf(
                1.14f, -0.04f, -0.02f, 0f, -10f,
                -0.02f, 1.08f, -0.02f, 0f, -8f,
                -0.02f, -0.04f, 1.12f, 0f, -6f,
                0f, 0f, 0f, 1f, 0f
            )
            GodlyFilterStyle.ZEISS_INSPIRED -> floatArrayOf(
                1.04f, 0.0f, 0.0f, 0f, 2f,
                0.0f, 1.06f, 0.02f, 0f, 2f,
                0.0f, 0.02f, 1.08f, 0f, 4f,
                0f, 0f, 0f, 1f, 0f
            )
            GodlyFilterStyle.HASSELBLAD_INSPIRED -> floatArrayOf(
                1.06f, 0.03f, -0.02f, 0f, 4f,
                0.01f, 1.03f, 0.01f, 0f, 3f,
                -0.02f, 0.02f, 0.98f, 0f, 2f,
                0f, 0f, 0f, 1f, 0f
            )
            GodlyFilterStyle.IOS_INSPIRED -> floatArrayOf(
                1.05f, 0.01f, 0.0f, 0f, 8f,
                0.0f, 1.04f, 0.0f, 0f, 7f,
                0.0f, 0.0f, 1.02f, 0f, 5f,
                0f, 0f, 0f, 1f, 0f
            )
            GodlyFilterStyle.NIGHT_NATURAL -> floatArrayOf(
                0.96f, 0.0f, 0.02f, 0f, 4f,
                0.0f, 1.04f, 0.02f, 0f, 6f,
                0.02f, 0.04f, 1.12f, 0f, 10f,
                0f, 0f, 0f, 1f, 0f
            )
            GodlyFilterStyle.CINEMATIC -> floatArrayOf(
                1.12f, 0.04f, -0.08f, 0f, -4f,
                -0.02f, 1.04f, 0.04f, 0f, 0f,
                -0.08f, 0.08f, 1.16f, 0f, 8f,
                0f, 0f, 0f, 1f, 0f
            )
            GodlyFilterStyle.PORTRAIT_WARM -> floatArrayOf(
                1.08f, 0.02f, 0.0f, 0f, 6f,
                0.01f, 1.03f, 0.0f, 0f, 4f,
                0.0f, 0.0f, 0.95f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            )
            GodlyFilterStyle.BLACK_AND_WHITE -> floatArrayOf(
                0.33f, 0.59f, 0.11f, 0f, -5f,
                0.33f, 0.59f, 0.11f, 0f, -5f,
                0.33f, 0.59f, 0.11f, 0f, -5f,
                0f, 0f, 0f, 1f, 0f
            )
        }
    }

    fun buildActiveColorMatrix(): ColorMatrix {
        val target = getBaseMatrix(currentStyle)
        val blended = FloatArray(20)
        val t = filterIntensity.coerceIn(0f, 1f)
        for (i in 0 until 20) {
            blended[i] = identityMatrix[i] * (1f - t) + target[i] * t
        }
        return ColorMatrix(blended)
    }

    fun renderFilteredBitmap(source: Bitmap): Bitmap {
        if (currentStyle == GodlyFilterStyle.ORIGINAL || filterIntensity <= 0.01f) {
            return source.copy(Bitmap.Config.ARGB_8888, false)
        }
        val output = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.colorFilter = ColorMatrixColorFilter(buildActiveColorMatrix())
        canvas.drawBitmap(source, 0f, 0f, paint)
        return output
    }
}
