package com.godly.cameraai

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.MotionEvent
import android.view.View
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.godly.cameraai.ai.AIEnhancementEngine
import com.godly.cameraai.ai.RestoreMode
import com.godly.cameraai.camera.CameraController
import com.godly.cameraai.camera.ZoomController
import com.godly.cameraai.computational.NightCaptureEngine
import com.godly.cameraai.databinding.ActivityMainBinding
import com.godly.cameraai.filters.FilterEngine
import com.godly.cameraai.filters.GodlyFilterStyle
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.pow

enum class CameraMode(val title: String) {
    PHOTO("PHOTO"),
    NIGHT("AI NIGHT"),
    MILKY_WAY("MILKY WAY"),
    PORTRAIT("PORTRAIT"),
    PRO("PRO")
}

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var cameraController: CameraController
    private lateinit var nightEngine: NightCaptureEngine
    private lateinit var aiEngine: AIEnhancementEngine
    private lateinit var zoomController: ZoomController
    private val filterEngine = FilterEngine()

    private var currentMode = CameraMode.NIGHT
    private var restoreMode = RestoreMode.FAITHFUL_RESTORE
    private var currentLensFacing = CameraSelector.LENS_FACING_BACK
    private var activeCaptureJob: Job? = null

    private var lastOriginalBitmap: Bitmap? = null
    private var lastProcessedBitmap: Bitmap? = null
    private var showingBeforeImage = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        aiEngine = AIEnhancementEngine(this)
        val modelInitMsg = aiEngine.initializeModels()
        Toast.makeText(this, modelInitMsg, Toast.LENGTH_LONG).show()

        cameraController = CameraController(this, this, binding.viewFinder) { lum ->
            runOnUiThread { updateTelemetryHeader(lum) }
        }
        nightEngine = NightCaptureEngine(this, cameraController)
        zoomController = ZoomController(cameraController, binding.viewFinder)

        setupModeSelector()
        setupZoomControls()
        setupTopBarControls()
        setupProControls()
        setupTouchToFocus()
        setupShutterAndActions()

        if (hasPermissions()) {
            startCameraSession()
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.CAMERA),
                1001
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1001 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startCameraSession()
        }
    }

    private fun startCameraSession() {
        cameraController.startCamera(currentLensFacing) { caps ->
            runOnUiThread {
                val levelStr = when (caps.hardwareLevel) {
                    0 -> "LIMITED"
                    1 -> "FULL"
                    2 -> "LEGACY"
                    3 -> "LEVEL_3"
                    else -> "EXTERNAL"
                }
                binding.tvTelemetryInfo.text =
                    "HAL: $levelStr | Manual: ${if (caps.supportsManualSensor) "Mở" else "Khóa"} | RAW: ${if (caps.supportsRaw) "Có" else "Không"}"
            }
        }
    }

    private fun updateTelemetryHeader(lum: Double) {
        val zoomStr = if (zoomController.currentZoom >= 10f) {
            "${zoomController.currentZoom.toInt()}x"
        } else {
            "${"%.1f".format(zoomController.currentZoom)}x"
        }

        val modeHint = when (currentMode) {
            CameraMode.NIGHT -> {
                val plan = nightEngine.analyzeScene(false)
                "Night: ${plan.recommendedFrames} frames (~${plan.estimatedDurationMs / 1000}s)"
            }
            CameraMode.MILKY_WAY -> {
                val plan = nightEngine.analyzeScene(true)
                plan.warningMessage ?: "Tripod OK | Stacking ${plan.recommendedFrames} frames"
            }
            else -> "Mode: ${currentMode.title}"
        }
        binding.tvTelemetryInfo.text = "Zoom: $zoomStr | Độ sáng: ${lum.toInt()} | $modeHint"
    }

    private fun setupModeSelector() {
        binding.layoutModes.removeAllViews()
        CameraMode.entries.forEach { mode ->
            val tv = TextView(this).apply {
                text = mode.title
                textSize = 13f
                setPadding(28, 12, 28, 12)
                setTextColor(if (mode == currentMode) 0xFFFF5722.toInt() else 0xFFFFFFFF.toInt())
                setOnClickListener {
                    currentMode = mode
                    binding.layoutProPanel.visibility = if (mode == CameraMode.PRO) View.VISIBLE else View.GONE
                    setupModeSelector()
                }
            }
            binding.layoutModes.addView(tv)
        }
    }

    private fun setupZoomControls() {
        binding.layoutZoomPresets.removeAllViews()
        zoomController.presetStops.forEach { stop ->
            val btn = TextView(this).apply {
                text = if (stop < 1f) "${stop}x" else "${stop.toInt()}x"
                textSize = 12f
                setPadding(22, 10, 22, 10)
                setTextColor(0xFFFFFFFF.toInt())
                setOnClickListener {
                    val status = zoomController.setZoomLevel(stop)
                    status.qualityWarning?.let { warn ->
                        Toast.makeText(this@MainActivity, warn, Toast.LENGTH_SHORT).show()
                    }
                }
            }
            binding.layoutZoomPresets.addView(btn)
        }

        binding.seekBarZoom.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val norm = progress / 1000.0
                    val expZoom = (0.6 * (200.0.pow(norm))).toFloat().coerceIn(0.6f, 120f)
                    zoomController.setZoomLevel(expZoom)
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    private fun setupTopBarControls() {
        binding.tvAiToggle.setOnClickListener {
            restoreMode = if (restoreMode == RestoreMode.FAITHFUL_RESTORE) {
                Toast.makeText(
                    this,
                    "AI Detail Restore: Tái tạo mạnh hơn (Chi tiết cực mờ có thể là chi tiết do AI suy đoán).",
                    Toast.LENGTH_LONG
                ).show()
                RestoreMode.AI_DETAIL_RESTORE
            } else {
                RestoreMode.FAITHFUL_RESTORE
            }
            binding.tvAiToggle.text = if (restoreMode == RestoreMode.FAITHFUL_RESTORE) "AI: FAITHFUL" else "AI: DETAIL+"
        }

        val styles = GodlyFilterStyle.entries
        var styleIndex = 0
        binding.tvFilterButton.setOnClickListener {
            styleIndex = (styleIndex + 1) % styles.size
            filterEngine.currentStyle = styles[styleIndex]
            binding.tvFilterButton.text = "FILTER: ${styles[styleIndex].name.take(8)}"
            binding.layoutFilterIntensity.visibility =
                if (filterEngine.currentStyle == GodlyFilterStyle.ORIGINAL) View.GONE else View.VISIBLE
        }

        binding.seekFilterIntensity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                filterEngine.filterIntensity = progress / 100f
                binding.tvFilterIntensity.text = "Cường độ: $progress%"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        binding.tvCompareToggle.setOnClickListener {
            val orig = lastOriginalBitmap
            val proc = lastProcessedBitmap
            if (orig == null || proc == null) {
                Toast.makeText(this, "Hãy chụp 1 bức ảnh để so sánh Trước / Sau.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (binding.ivComparisonOverlay.visibility == View.GONE) {
                binding.ivComparisonOverlay.visibility = View.VISIBLE
                showingBeforeImage = true
                binding.ivComparisonOverlay.setImageBitmap(orig)
                binding.tvCompareToggle.text = "XEM: GỐC"
            } else if (showingBeforeImage) {
                showingBeforeImage = false
                binding.ivComparisonOverlay.setImageBitmap(proc)
                binding.tvCompareToggle.text = "XEM: AI"
            } else {
                binding.ivComparisonOverlay.visibility = View.GONE
                binding.tvCompareToggle.text = "SO SÁNH"
            }
        }
    }

    private fun setupProControls() {
        binding.seekProIso.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val range = cameraController.currentCapabilities?.isoRange
                    val minIso = range?.lower ?: 100
                    val maxIso = range?.upper ?: 3200
                    val iso = minIso + ((maxIso - minIso) * progress / 100)
                    cameraController.proParams.isAuto = false
                    cameraController.proParams.iso = iso
                    binding.tvProIsoLabel.text = "ISO: $iso"
                    cameraController.applyProParameters()
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        binding.seekProShutter.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val expNs = (250_000.0 * (4000.0.pow(progress / 100.0))).toLong()
                    cameraController.proParams.isAuto = false
                    cameraController.proParams.shutterSpeedNs = expNs
                    val secText = if (expNs >= 100_000_000L) {
                        "${"%.1f".format(expNs / 1e9)}s"
                    } else {
                        "1/${(1e9 / expNs).toInt()}s"
                    }
                    binding.tvProShutterLabel.text = "S: $secText"
                    cameraController.applyProParameters()
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        binding.btnProReset.setOnClickListener {
            cameraController.proParams.isAuto = true
            binding.tvProIsoLabel.text = "ISO: Auto"
            binding.tvProShutterLabel.text = "Shutter: Auto"
            cameraController.applyProParameters()
        }
    }

    private fun setupTouchToFocus() {
        binding.viewFinder.setOnTouchListener { view, event ->
            if (event.action == MotionEvent.ACTION_UP) {
                val factory = binding.viewFinder.meteringPointFactory
                val point = factory.createPoint(event.x, event.y)
                val action = FocusMeteringAction.Builder(point).build()
                cameraController.activeCamera?.cameraControl?.startFocusAndMetering(action)
                view.performClick()
            }
            true
        }
    }

    private fun setupShutterAndActions() {
        binding.btnSwitchCamera.setOnClickListener {
            currentLensFacing = if (currentLensFacing == CameraSelector.LENS_FACING_BACK) {
                CameraSelector.LENS_FACING_FRONT
            } else {
                CameraSelector.LENS_FACING_BACK
            }
            startCameraSession()
        }

        binding.btnCancelProcessing.setOnClickListener {
            activeCaptureJob?.cancel()
            binding.layoutProcessingOverlay.visibility = View.GONE
            Toast.makeText(this, "Đã hủy phơi sáng dài.", Toast.LENGTH_SHORT).show()
        }

        binding.btnShutter.setOnClickListener {
            if (activeCaptureJob?.isActive == true) return@setOnClickListener
            executeCaptureFlow()
        }
    }

    private fun executeCaptureFlow() {
        binding.layoutProcessingOverlay.visibility = View.VISIBLE
        binding.progressBarCapture.progress = 5

        activeCaptureJob = lifecycleScope.launch {
            try {
                val (rawFrame, stackedFrame) = when (currentMode) {
                    CameraMode.NIGHT -> nightEngine.executeNightOrMilkyWayCapture(
                        isMilkyWayMode = false,
                        enableAiToneMapping = true,
                        fastFallback = false
                    ) { p, msg ->
                        runOnUiThread {
                            binding.progressBarCapture.progress = p / 2
                            binding.tvProgressStatus.text = msg
                        }
                    }

                    CameraMode.MILKY_WAY -> nightEngine.executeNightOrMilkyWayCapture(
                        isMilkyWayMode = true,
                        enableAiToneMapping = true,
                        fastFallback = false
                    ) { p, msg ->
                        runOnUiThread {
                            binding.progressBarCapture.progress = p / 2
                            binding.tvProgressStatus.text = msg
                        }
                    }

                    else -> {
                        runOnUiThread { binding.tvProgressStatus.text = "Đang thu khung hình gốc..." }
                        val single = cameraController.captureSingleFrame()
                        Pair(single.copy(Bitmap.Config.ARGB_8888, false), single)
                    }
                }

                val zoomProcessed = zoomController.applyExtendedZoomCrop(stackedFrame)

                val aiEnhanced = aiEngine.processImagePipeline(
                    input = zoomProcessed,
                    mode = restoreMode,
                    scaleFactor = if (zoomController.currentZoom >= 10f) 2 else 1
                ) { p, msg ->
                    runOnUiThread {
                        binding.progressBarCapture.progress = 50 + (p / 2)
                        binding.tvProgressStatus.text = msg
                    }
                }

                val finalOutput = filterEngine.renderFilteredBitmap(aiEnhanced)

                saveImageToGallery(rawFrame, prefix = "GODLY_ORIGINAL")
                saveImageToGallery(finalOutput, prefix = "GODLY_AI_${currentMode.name}")

                lastOriginalBitmap?.recycle()
                lastProcessedBitmap?.recycle()
                lastOriginalBitmap = rawFrame
                lastProcessedBitmap = finalOutput

                binding.ivLastThumbnail.setImageBitmap(finalOutput)
                binding.layoutProcessingOverlay.visibility = View.GONE
                Toast.makeText(
                    this@MainActivity,
                    "Đã lưu ảnh Gốc & ảnh AI vào Pictures/GodlyCameraAI!",
                    Toast.LENGTH_SHORT
                ).show()

            } catch (e: Exception) {
                binding.layoutProcessingOverlay.visibility = View.GONE
                Toast.makeText(this@MainActivity, "Lỗi xử lý: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun saveImageToGallery(bitmap: Bitmap, prefix: String) {
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val filename = "${prefix}_$timestamp.jpg"

        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, filename)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/GodlyCameraAI")
            }
        }

        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return
        contentResolver.openOutputStream(uri)?.use { outStream ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 96, outStream)
        }
    }

    private fun hasPermissions(): Boolean {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    }

    override fun onDestroy() {
        super.onDestroy()
        aiEngine.release()
    }
}
