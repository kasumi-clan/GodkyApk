package com.godly.cameraai.camera

import android.graphics.Bitmap
import androidx.camera.view.PreviewView
import kotlin.math.min
import kotlin.math.roundToInt

data class ZoomStatus(
    val requestedZoom: Float,
    val halAppliedZoom: Float,
    val softwareMultiplier: Float,
    val activeLensLabel: String,
    val qualityEstimate: String,
    val qualityWarning: String?
)

class ZoomController(
    private val cameraController: CameraController,
    private val previewView: PreviewView
) {
    val presetStops = listOf(0.6f, 1.0f, 2.0f, 3.0f, 5.0f, 10.0f, 30.0f, 60.0f, 120.0f)

    var currentZoom: Float = 1.0f
        private set

    fun setZoomLevel(targetZoom: Float): ZoomStatus {
        val cam = cameraController.activeCamera
        val zoomState = cam?.cameraInfo?.zoomState?.value
        val minHalZoom = zoomState?.minZoomRatio ?: 1.0f
        val maxHalZoom = zoomState?.maxZoomRatio ?: 8.0f

        val clampedTarget = targetZoom.coerceIn(min(0.6f, minHalZoom), 120.0f)
        currentZoom = clampedTarget

        val halZoom = clampedTarget.coerceIn(minHalZoom, maxHalZoom)
        cam?.cameraControl?.setZoomRatio(halZoom)

        val swFactor = if (clampedTarget > maxHalZoom) {
            clampedTarget / maxHalZoom
        } else {
            1.0f
        }

        previewView.scaleX = swFactor
        previewView.scaleY = swFactor

        val lensLabel = when {
            clampedTarget < 0.95f -> "Ultra-Wide (0.6x)"
            clampedTarget <= 2.0f -> "Main Sensor (1x)"
            clampedTarget <= 10.0f -> "Hybrid Tele (${"%.1f".format(clampedTarget)}x)"
            else -> "AI Super-Zoom (${clampedTarget.roundToInt()}x)"
        }

        val qualityEst = when {
            clampedTarget <= 2.0f -> "Lossless / Optical Grade"
            clampedTarget <= 10.0f -> "High (Hybrid Multi-Frame)"
            clampedTarget <= 30.0f -> "Medium (Digital + AI Restore)"
            else -> "Extreme Digital Zoom (AI Assisted)"
        }

        val warning = when {
            clampedTarget >= 30.0f ->
                "Mức zoom số ${clampedTarget.roundToInt()}× vượt xa tiêu cự quang học. Hãy giữ thật chắc tay; AI sẽ hỗ trợ khử răng cưa và tái tạo biên ảnh."
            clampedTarget > maxHalZoom ->
                "Đang kết hợp Zoom phần cứng (${"%.1f".format(maxHalZoom)}×) và phóng đại số AI."
            else -> null
        }

        return ZoomStatus(clampedTarget, halZoom, swFactor, lensLabel, qualityEstimate = qualityEst, qualityWarning = warning)
    }

    fun applyExtendedZoomCrop(capturedBitmap: Bitmap): Bitmap {
        val cam = cameraController.activeCamera
        val maxHalZoom = cam?.cameraInfo?.zoomState?.value?.maxZoomRatio ?: 8.0f
        if (currentZoom <= maxHalZoom) return capturedBitmap

        val swFactor = (currentZoom / maxHalZoom).coerceAtMost(15.0f)
        val cropW = (capturedBitmap.width / swFactor).roundToInt().coerceAtLeast(64)
        val cropH = (capturedBitmap.height / swFactor).roundToInt().coerceAtLeast(64)
        val startX = (capturedBitmap.width - cropW) / 2
        val startY = (capturedBitmap.height - cropH) / 2

        val cropped = Bitmap.createBitmap(capturedBitmap, startX, startY, cropW, cropH)
        val upscaled = Bitmap.createScaledBitmap(cropped, capturedBitmap.width, capturedBitmap.height, true)
        if (cropped !== upscaled) cropped.recycle()
        return upscaled
    }
}
