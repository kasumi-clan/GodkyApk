package com.godly.cameraai.camera

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.util.Range
import androidx.annotation.OptIn
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.nio.ByteBuffer
import java.util.concurrent.Executors
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

data class HardwareCapabilities(
    val cameraId: String,
    val hardwareLevel: Int,
    val isoRange: Range<Int>?,
    val exposureTimeRangeNs: Range<Long>?,
    val maxDigitalZoom: Float,
    val minFocusDistance: Float,
    val supportsManualSensor: Boolean,
    val supportsRaw: Boolean,
    val focalLengths: FloatArray
)

data class ProParameters(
    var isAuto: Boolean = true,
    var iso: Int? = null,
    var shutterSpeedNs: Long? = null,
    var exposureCompensationIndex: Int = 0,
    var focusDistance: Float? = null,
    var kelvinWB: Int? = null
)

@OptIn(ExperimentalCamera2Interop::class)
class CameraController(
    private val context: Context,
    private val lifecycleOwner: LifecycleOwner,
    private val previewView: PreviewView,
    private val onLuminanceUpdated: (Double) -> Unit
) {
    private var cameraProvider: ProcessCameraProvider? = null
    var activeCamera: Camera? = null
        private set
    var imageCapture: ImageCapture? = null
        private set

    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager

    var currentCapabilities: HardwareCapabilities? = null
        private set
    val proParams = ProParameters()
    var currentLuminance: Double = 50.0
        private set

    fun startCamera(lensFacing: Int = CameraSelector.LENS_FACING_BACK, onReady: (HardwareCapabilities) -> Unit) {
        val providerFuture = ProcessCameraProvider.getInstance(context)
        providerFuture.addListener({
            val provider = providerFuture.get()
            cameraProvider = provider

            val selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()

            val preview = Preview.Builder()
                .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                .build()
                .also { it.setSurfaceProvider(previewView.surfaceProvider) }

            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                .build()

            val imageAnalyzer = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
                .also { analysis ->
                    analysis.setAnalyzer(cameraExecutor) { image ->
                        currentLuminance = calculateLuminance(image)
                        onLuminanceUpdated(currentLuminance)
                        image.close()
                    }
                }

            try {
                provider.unbindAll()
                val cam = provider.bindToLifecycle(lifecycleOwner, selector, preview, imageCapture, imageAnalyzer)
                activeCamera = cam
                val caps = inspectHardwareCapabilities(cam)
                currentCapabilities = caps
                onReady(caps)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }, ContextCompat.getMainExecutor(context))
    }

    private fun inspectHardwareCapabilities(camera: Camera): HardwareCapabilities {
        val cam2Info = Camera2CameraInfo.from(camera.cameraInfo)
        val camId = cam2Info.cameraId
        val chars = cameraManager.getCameraCharacteristics(camId)

        val hwLevel = chars.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL)
            ?: CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LEGACY
        val isoRange = chars.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
        val expRange = chars.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
        val maxZoom = chars.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM) ?: 10f
        val minFocus = chars.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
        val capabilities = chars.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: IntArray(0)
        val focalLengths = chars.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS) ?: floatArrayOf(4.2f)

        val supportsManual = capabilities.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR)
        val supportsRaw = capabilities.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_RAW)

        return HardwareCapabilities(
            cameraId = camId,
            hardwareLevel = hwLevel,
            isoRange = isoRange,
            exposureTimeRangeNs = expRange,
            maxDigitalZoom = maxZoom,
            minFocusDistance = minFocus,
            supportsManualSensor = supportsManual,
            supportsRaw = supportsRaw,
            focalLengths = focalLengths
        )
    }

    fun applyProParameters() {
        val cam = activeCamera ?: return
        val caps = currentCapabilities ?: return
        val cam2Control = Camera2CameraControl.from(cam.cameraControl)

        val builder = CaptureRequestOptions.Builder()

        if (proParams.isAuto || !caps.supportsManualSensor) {
            builder.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON)
            builder.setCaptureRequestOption(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
            builder.setCaptureRequestOption(CaptureRequest.CONTROL_AWB_MODE, CameraMetadata.CONTROL_AWB_MODE_AUTO)
            builder.setCaptureRequestOption(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, proParams.exposureCompensationIndex)
        } else {
            builder.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_OFF)
            proParams.iso?.let { isoVal ->
                val clampedIso = caps.isoRange?.clamp(isoVal) ?: isoVal
                builder.setCaptureRequestOption(CaptureRequest.SENSOR_SENSITIVITY, clampedIso)
            }
            proParams.shutterSpeedNs?.let { shutterVal ->
                val clampedShutter = caps.exposureTimeRangeNs?.clamp(shutterVal) ?: shutterVal
                builder.setCaptureRequestOption(CaptureRequest.SENSOR_EXPOSURE_TIME, clampedShutter)
            }

            if (proParams.focusDistance != null && caps.minFocusDistance > 0f) {
                builder.setCaptureRequestOption(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_OFF)
                builder.setCaptureRequestOption(
                    CaptureRequest.LENS_FOCUS_DISTANCE,
                    proParams.focusDistance!!.coerceIn(0f, caps.minFocusDistance)
                )
            }
        }

        cam2Control.setCaptureRequestOptions(builder.build())
    }

    suspend fun captureSingleFrame(): Bitmap = withContext(Dispatchers.IO) {
        val capture = imageCapture ?: throw IllegalStateException("Camera chưa sẵn sàng")
        suspendCancellableCoroutine { cont ->
            capture.takePicture(
                cameraExecutor,
                object : ImageCapture.OnImageCapturedCallback() {
                    override fun onCaptureSuccess(image: ImageProxy) {
                        try {
                            val bitmap = imageProxyToBitmap(image)
                            image.close()
                            if (cont.isActive) cont.resume(bitmap)
                        } catch (e: Exception) {
                            image.close()
                            if (cont.isActive) cont.resumeWithException(e)
                        }
                    }

                    override fun onError(exception: ImageCaptureException) {
                        if (cont.isActive) cont.resumeWithException(exception)
                    }
                }
            )
        }
    }

    fun setBurstExposureStep(evIndex: Int, manualIso: Int? = null, manualShutterNs: Long? = null) {
        val cam = activeCamera ?: return
        val caps = currentCapabilities ?: return
        val cam2Control = Camera2CameraControl.from(cam.cameraControl)
        val builder = CaptureRequestOptions.Builder()

        if (caps.supportsManualSensor && manualIso != null && manualShutterNs != null) {
            builder.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_OFF)
            builder.setCaptureRequestOption(CaptureRequest.SENSOR_SENSITIVITY, caps.isoRange?.clamp(manualIso) ?: manualIso)
            builder.setCaptureRequestOption(CaptureRequest.SENSOR_EXPOSURE_TIME, caps.exposureTimeRangeNs?.clamp(manualShutterNs) ?: manualShutterNs)
        } else {
            builder.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON)
            builder.setCaptureRequestOption(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, evIndex)
        }
        cam2Control.setCaptureRequestOptions(builder.build())
    }

    private fun calculateLuminance(image: ImageProxy): Double {
        val buffer: ByteBuffer = image.planes[0].buffer
        val data = ByteArray(buffer.remaining())
        buffer.get(data)
        var sum = 0L
        val step = 8
        var count = 0
        for (i in data.indices step step) {
            sum += (data[i].toInt() and 0xFF)
            count++
        }
        return if (count > 0) sum.toDouble() / count else 0.0
    }

    private fun imageProxyToBitmap(image: ImageProxy): Bitmap {
        val buffer = image.planes[0].buffer
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            ?: throw IllegalStateException("Không thể giải mã khung hình từ cảm biến")
    }
}
