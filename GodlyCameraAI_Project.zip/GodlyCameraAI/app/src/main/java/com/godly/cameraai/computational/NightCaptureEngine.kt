package com.godly.cameraai.computational

import android.content.Context
import android.graphics.Bitmap
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import com.godly.cameraai.camera.CameraController
import kotlinx.coroutines.*
import kotlin.math.*

data class SceneAnalysisResult(
    val averageLuminance: Double,
    val recommendedFrames: Int,
    val estimatedDurationMs: Long,
    val isTripodSteady: Boolean,
    val warningMessage: String?
)

class NightCaptureEngine(
    context: Context,
    private val cameraController: CameraController
) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    @Volatile
    private var motionMagnitude: Float = 0f
    private var lastAccel = FloatArray(3)

    init {
        sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event?.sensor?.type == Sensor.TYPE_ACCELEROMETER) {
            val dx = event.values[0] - lastAccel[0]
            val dy = event.values[1] - lastAccel[1]
            val dz = event.values[2] - lastAccel[2]
            motionMagnitude = sqrt(dx * dx + dy * dy + dz * dz)
            lastAccel = event.values.clone()
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    fun analyzeScene(isMilkyWayMode: Boolean, fastFallback: Boolean = false): SceneAnalysisResult {
        val lum = cameraController.currentLuminance
        val isSteady = motionMagnitude < 0.28f

        if (isMilkyWayMode) {
            val warning = when {
                !isSteady -> "Cảnh báo: Điện thoại đang rung. Hãy đặt lên Tripod để chụp Dải Ngân Hà."
                lum > 45.0 -> "Cảnh báo: Môi trường quá sáng, khó thấy rõ cấu trúc Milky Way."
                cameraController.currentCapabilities?.supportsManualSensor == false ->
                    "Phần cứng khóa phơi sáng dài thủ công. Chuyển sang Multi-Frame Stacking."
                else -> null
            }
            val frames = if (fastFallback) 6 else 14
            return SceneAnalysisResult(lum, frames, frames * 700L, isSteady, warning)
        }

        return when {
            fastFallback -> SceneAnalysisResult(lum, 3, 1500L, isSteady, null)
            lum < 18.0 -> SceneAnalysisResult(lum, 9, 6500L, isSteady, "Cảnh rất tối: Giữ chắc tay trong quá trình ghép ảnh.")
            lum < 55.0 -> SceneAnalysisResult(lum, 6, 3200L, isSteady, null)
            else -> SceneAnalysisResult(lum, 4, 2000L, isSteady, null)
        }
    }

    suspend fun executeNightOrMilkyWayCapture(
        isMilkyWayMode: Boolean,
        enableAiToneMapping: Boolean,
        fastFallback: Boolean,
        onProgress: (Int, String) -> Unit
    ): Pair<Bitmap, Bitmap> = withContext(Dispatchers.Default) {
        val plan = analyzeScene(isMilkyWayMode, fastFallback)
        val totalFrames = plan.recommendedFrames
        val capturedFrames = mutableListOf<Bitmap>()

        try {
            if (isMilkyWayMode) {
                cameraController.proParams.isAuto = false
                cameraController.proParams.focusDistance = 0.0f
                cameraController.applyProParameters()
            }

            for (i in 0 until totalFrames) {
                ensureActive()
                val evStep = when {
                    isMilkyWayMode -> 2
                    i == 0 -> 0
                    i % 3 == 1 -> -2
                    else -> 2
                }
                cameraController.setBurstExposureStep(
                    evIndex = evStep,
                    manualIso = if (isMilkyWayMode) 1600 else null,
                    manualShutterNs = if (isMilkyWayMode) 500_000_000L else null
                )
                delay(90)
                val frame = cameraController.captureSingleFrame()
                capturedFrames.add(frame)

                val progress = ((i + 1).toFloat() / totalFrames * 55f).toInt()
                onProgress(progress, "Đang thu sáng khung hình ${i + 1}/$totalFrames...")
            }

            cameraController.proParams.isAuto = true
            cameraController.applyProParameters()

            val referenceCopy = capturedFrames.first().copy(Bitmap.Config.ARGB_8888, false)

            onProgress(65, "Đang căn chỉnh khung hình & khử nhiễu đa tầng...")
            val stackedBitmap = alignAndMergeFrames(capturedFrames, isMilkyWayMode) { mergeProg ->
                onProgress(65 + (mergeProg * 20).toInt(), "Đang xếp chồng tín hiệu cảm biến...")
            }

            for (i in 1 until capturedFrames.size) {
                capturedFrames[i].recycle()
            }

            val finalBitmap = if (enableAiToneMapping) {
                onProgress(90, if (isMilkyWayMode) "Đang cân bằng nền trời & làm nổi bật sao..." else "Đang phục hồi vùng tối & chống cháy sáng...")
                applyRegionalNightToneMapping(stackedBitmap, isMilkyWayMode)
            } else {
                stackedBitmap
            }

            onProgress(100, "Hoàn tất xử lý chụp đêm!")
            Pair(referenceCopy, finalBitmap)
        } catch (e: CancellationException) {
            capturedFrames.forEach { if (!it.isRecycled) it.recycle() }
            cameraController.proParams.isAuto = true
            cameraController.applyProParameters()
            throw e
        }
    }

    private suspend fun alignAndMergeFrames(
        frames: List<Bitmap>,
        isMilkyWay: Boolean,
        onMergeProgress: (Float) -> Unit
    ): Bitmap = withContext(Dispatchers.Default) {
        val ref = frames[0]
        val width = ref.width
        val height = ref.height
        val numFrames = frames.size

        val offsets = Array(numFrames) { IntArray(2) }
        for (idx in 1 until numFrames) {
            ensureActive()
            offsets[idx] = estimateFrameOffset(ref, frames[idx])
        }

        val outBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val bandHeight = 128

        val refPixels = IntArray(width * bandHeight)
        val curPixels = IntArray(width * bandHeight)
        val outPixels = IntArray(width * bandHeight)

        var yStart = 0
        while (yStart < height) {
            ensureActive()
            val currentBandH = min(bandHeight, height - yStart)
            ref.getPixels(refPixels, 0, width, 0, yStart, width, currentBandH)

            val sumR = FloatArray(width * currentBandH)
            val sumG = FloatArray(width * currentBandH)
            val sumB = FloatArray(width * currentBandH)
            val sumW = FloatArray(width * currentBandH)

            for (i in 0 until width * currentBandH) {
                val c = refPixels[i]
                sumR[i] = ((c shr 16) and 0xFF).toFloat()
                sumG[i] = ((c shr 8) and 0xFF).toFloat()
                sumB[i] = (c and 0xFF).toFloat()
                sumW[i] = 1.0f
            }

            for (fIdx in 1 until numFrames) {
                val dx = offsets[fIdx][0]
                val dy = offsets[fIdx][1]
                val frame = frames[fIdx]

                val sampleY = (yStart + dy).coerceIn(0, height - currentBandH)
                frame.getPixels(curPixels, 0, width, 0, sampleY, width, currentBandH)

                for (row in 0 until currentBandH) {
                    val rowOffset = row * width
                    for (col in 0 until width) {
                        val sampleCol = (col + dx).coerceIn(0, width - 1)
                        val pRef = refPixels[rowOffset + col]
                        val pCur = curPixels[rowOffset + sampleCol]

                        val rRef = (pRef shr 16) and 0xFF
                        val gRef = (pRef shr 8) and 0xFF
                        val bRef = pRef and 0xFF

                        val rCur = (pCur shr 16) and 0xFF
                        val gCur = (pCur shr 8) and 0xFF
                        val bCur = pCur and 0xFF

                        val diff = (abs(rRef - rCur) + abs(gRef - gCur) + abs(bRef - bCur)) / 3f
                        val ghostThreshold = if (isMilkyWay) 38f else 28f
                        val weight = if (diff > ghostThreshold) {
                            max(0.05f, 1f - (diff - ghostThreshold) / 60f)
                        } else {
                            1.0f
                        }

                        val idx = rowOffset + col
                        sumR[idx] += rCur * weight
                        sumG[idx] += gCur * weight
                        sumB[idx] += bCur * weight
                        sumW[idx] += weight
                    }
                }
            }

            for (i in 0 until width * currentBandH) {
                val w = sumW[i]
                val r = (sumR[i] / w).toInt().coerceIn(0, 255)
                val g = (sumG[i] / w).toInt().coerceIn(0, 255)
                val b = (sumB[i] / w).toInt().coerceIn(0, 255)
                outPixels[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            }

            outBitmap.setPixels(outPixels, 0, width, 0, yStart, width, currentBandH)
            yStart += currentBandH
            onMergeProgress(yStart.toFloat() / height)
        }

        outBitmap
    }

    private fun estimateFrameOffset(ref: Bitmap, target: Bitmap): IntArray {
        val patchSize = 96
        val cx = ref.width / 2 - patchSize / 2
        val cy = ref.height / 2 - patchSize / 2
        if (cx <= 16 || cy <= 16) return intArrayOf(0, 0)

        val refPatch = IntArray(patchSize * patchSize)
        val tarPatch = IntArray(patchSize * patchSize)
        ref.getPixels(refPatch, 0, patchSize, cx, cy, patchSize, patchSize)

        var bestDx = 0
        var bestDy = 0
        var minSad = Long.MAX_VALUE
        val searchRadius = 8

        for (dy in -searchRadius..searchRadius step 2) {
            for (dx in -searchRadius..searchRadius step 2) {
                target.getPixels(tarPatch, 0, patchSize, cx + dx, cy + dy, patchSize, patchSize)
                var sad = 0L
                for (i in refPatch.indices step 4) {
                    val g1 = (refPatch[i] shr 8) and 0xFF
                    val g2 = (tarPatch[i] shr 8) and 0xFF
                    sad += abs(g1 - g2)
                }
                if (sad < minSad) {
                    minSad = sad
                    bestDx = dx
                    bestDy = dy
                }
            }
        }
        return intArrayOf(bestDx, bestDy)
    }

    private fun applyRegionalNightToneMapping(source: Bitmap, isMilkyWay: Boolean): Bitmap {
        val width = source.width
        val height = source.height
        val result = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val bandH = 128
        val pixels = IntArray(width * bandH)

        val toneLut = IntArray(256)
        for (i in 0..255) {
            val norm = i / 255.0
            val mapped = if (isMilkyWay) {
                val skyContrast = norm.pow(1.18)
                val starBoost = 1.0 - (1.0 - skyContrast).pow(1.65)
                (starBoost * 255.0).roundToInt()
            } else {
                val shadowLifted = norm.pow(0.68)
                val highlightProtected = shadowLifted / (1.0 + 0.25 * shadowLifted.pow(2.2)) * 1.22
                (highlightProtected * 255.0).roundToInt()
            }
            toneLut[i] = mapped.coerceIn(0, 255)
        }

        var y = 0
        while (y < height) {
            val h = min(bandH, height - y)
            source.getPixels(pixels, 0, width, 0, y, width, h)
            val isUpperSkyRegion = (y.toFloat() / height) < 0.45f

            for (i in 0 until width * h) {
                val c = pixels[i]
                var r = (c shr 16) and 0xFF
                var g = (c shr 8) and 0xFF
                var b = c and 0xFF

                r = toneLut[r]
                g = toneLut[g]
                b = toneLut[b]

                if (isMilkyWay && isUpperSkyRegion) {
                    r = (r * 0.94f).toInt().coerceIn(0, 255)
                    b = (b * 1.07f).toInt().coerceIn(0, 255)
                }

                pixels[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            }
            result.setPixels(pixels, 0, width, 0, y, width, h)
            y += h
        }
        return result
    }
}
